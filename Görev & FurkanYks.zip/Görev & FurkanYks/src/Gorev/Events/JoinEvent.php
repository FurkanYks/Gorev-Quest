<?php

namespace Gorev\Events;

use pocketmine\event\Listener;
use pocketmine\{Player, Server};

use pocketmine\utils\Config;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class JoinEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
  public function aonJoin(PlayerJoinEvent $e){
    $player = $e->getPlayer();
$name = $player->getName();


 if(!$this->plugin->zaman->exists($name)){
        $this->random1($player);
        $this->random2($player);
        $this->random3($player);
        $zaman = strtotime("+1 days", time());
        $this->plugin->zaman->set($name, $zaman);
        $this->plugin->zaman->save();
      }

      if($this->plugin->zaman->get($name) < time()){
        $this->random1($player);
        $this->random2($player);
        $this->random3($player);
        $zaman = strtotime("+1 days", time());
        $this->plugin->zaman->set($name, $zaman);
        $this->plugin->zaman->save();
    }
  }
public function random1($p){
   $player = $p->getPlayer();
		$random1 = rand(1,3);
		
	    switch($random1){
	        case 1:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random1", "BenBirMimarim");
$this->config->set("benbirmimarim", "tamamlanmadi");

		$this->config->save();
	            break;
	            case 2:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random1", "Elmass");
$this->config->set("elmass", "tamamlanmadi");

		$this->config->save();
	                break;
	                case 3:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random1", "Çalışkan");
$this->config->set("caliskan", "tamamlanmadi");


		$this->config->save();
	                    break;
	        
	    }
	}
public function random2($p){
   $player = $p->getPlayer();
		$random1 = rand(1,3);
		
	    switch($random1){
	        case 1:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random2", "Depo");
$this->config->set("depo", "tamamlanmadi");

		$this->config->save();
	            break;
	            case 2:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random2", "işsiz");
$this->config->set("issiz", "tamamlanmadi");

		$this->config->save();
	                break;
	                case 3:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random2", "ParaGöz");
$this->config->set("paragoz", "tamamlanmadi");

		$this->config->save();
	                    break;
	        
	    }
	}
public function random3($p){
   $player = $p->getPlayer();
		$random1 = rand(1,3);
		
	    switch($random1){
	        case 1:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random3", "Oduncu");
$this->config->set("oduncu", "tamamlanmadi");

		$this->config->save();
	            break;
	            case 2:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random3", "Çaylak");
$this->config->set("caylak", "tamamlanmadi");

		$this->config->save();
	                break;
	                case 3:
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
$this->config->set("random3", "Savaşçı");
$this->config->set("savasci", "tamamlanmadi");

		$this->config->save();
	                    break;
	        
	    }
	}
}