<?php

namespace Gorev\Events;

use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\block\BlockPlaceEvent;
use onebone\economyapi\EconomyAPI;


use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class PlaceEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
	public function BlockKoyma(BlockPlaceEvent $e){
 $isim = $e->getPlayer()->getName();
		$player = $e->getPlayer();	
	$block = $e->getBlock();
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);

if($this->config->get("secilengorev") == "BenBirMimarim"){
if($this->config->get("random1") == "BenBirMimarim"){


            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
    //        $bt = $this->config->get("bitirdigingorevler");
            //        $this->config->set("bitirdigingorevler", $bt+1);
		$this->config->save();
if($this->config->get("min") == 251){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("benbirmimarim") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("benbirmimarim", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fBenBirMimarim,");
$this->config->set("random1", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();
		}
}
}
}
if($this->config->get("secilengorev") == "Çalışkan"){
if($this->config->get("random1") == "Çalışkan"){
	if($e->getBlock()->getId() == 58){

            $zengini = $this->config->get("min");
                    $this->config->set("min", $zengini+1);
		$this->config->save();
if($this->config->get("min") == 11){
		$this->config->save();
		
            $zengini = $this->config->get("min");
                    $this->config->set("min", $zengini-1);
		$this->config->save();
if($this->config->get("caliskan") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("caliskan", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fÇalışkan,");
$this->config->set("random1", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();
}
		}
	}
}
}


$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
if($this->config->get("secilengorev") == "Depo"){
if($this->config->get("random2") == "Depo"){
	if($e->getBlock()->getId() == 54){

            $depoi = $this->config->get("min");
                    $this->config->set("min", $depoi+1);
		$this->config->save();
		
if($this->config->get("min") == 6){
		$this->config->save();
		
            $depoi = $this->config->get("min");
                    $this->config->set("min", $depoi-1);
		$this->config->save();
if($this->config->get("depo") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("depo", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fDepo,");
$this->config->set("random2", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();
}
		}
	}
}
}
}
}
