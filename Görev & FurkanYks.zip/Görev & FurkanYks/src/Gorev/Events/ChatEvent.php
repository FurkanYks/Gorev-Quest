<?php

namespace Gorev\Events;

use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\block\BlockPlaceEvent;


use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class ChatEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
}