<?php

namespace Gorev\Events;

use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerDeathEvent;
use onebone\economyapi\EconomyAPI;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class DeathEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
public function onDeath(PlayerDeathEvent $event){
    $player = $event->getPlayer();
  $cid = $player->getLastDamageCause()->getCause();
   switch($cid){
     case EntityDamageEvent::CAUSE_VOID:
         
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);

if($this->config->get("secilengorev") == "Çaylak"){
if($this->config->get("random3") == "Çaylak"){
              $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
		$this->config->save();
if($this->config->get("min") == 6){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("caylak") == "tamamlanmadi"){
    
        $player = $event->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("caylak", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fÇaylak,");
$this->config->set("random3", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();

		}
       break;
}
}
}
}
}
}

