<?php

namespace Gorev\Events;

use jojoe77777\FormAPI;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\block\BlockBreakEvent;

use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class FormEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
  

}