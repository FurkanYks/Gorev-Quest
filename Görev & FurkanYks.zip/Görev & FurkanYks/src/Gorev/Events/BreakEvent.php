<?php

namespace Gorev\Events;

use onebone\economyapi\EconomyAPI;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\block\BlockBreakEvent;


use pocketmine\math\Vector3;
use pocketmine\item\Item;

use pocketmine\block\Block;
use pocketmine\level\Level;
use Gorev\Main;

class BreakEvent implements Listener{

  public function __construct(Main $eklenti){
    $this->plugin = $eklenti;
  }
  
	public function BlockKırma(BlockBreakEvent $e){
 $isim = $e->getPlayer()->getName();
		$player = $e->getPlayer();	
	$block = $e->getBlock();
$this->config = new Config($this->plugin->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);

if($this->config->get("secilengorev") == "işsiz"){
if($this->config->get("random2") == "işsiz"){


	if($e->getBlock()->getId() == 4){

            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
		$this->config->save();
if($this->config->get("min") == 651){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("issiz") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(550,1000)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("issiz", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fişsiz,");
$this->config->set("random2", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();

		}
	}
	}
}
}
if($this->config->get("secilengorev") == "Oduncu"){
if($this->config->get("random3") == "Oduncu"){


	if($e->getBlock()->getId() == 17){

            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
		$this->config->save();
if($this->config->get("min") == 65){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("oduncu") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("oduncu", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fOduncu,");
$this->config->set("random3", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();

		}
	}
	}
}
}
if($this->config->get("secilengorev") == "Elmass"){
if($this->config->get("random1") == "Elmass"){


	if($e->getBlock()->getId() == 57){

            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
		$this->config->save();
if($this->config->get("min") == 41){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("elmass") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("elmass", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fElmass,");
$this->config->set("random1", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();

		}
	}
	}
}
}
if($this->config->get("secilengorev") == "ParaGöz"){
if($this->config->get("random2") == "ParaGöz"){


	if($e->getBlock()->getId() == 57){

            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari+1);
		$this->config->save();
if($this->config->get("min") == 81){
		$this->config->save();
		
            $mimari = $this->config->get("min");
                    $this->config->set("min", $mimari-1);
		$this->config->save();
if($this->config->get("paragoz") == "tamamlanmadi"){
    
        $player = $e->getPlayer();
            $para = rand(150,500)*10;
            EconomyAPI::getInstance()->addMoney($player, $para);
              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
                $player->addTitle("§e$sg", "§fGörevi Tamamlandı!");
        $player->sendMessage("§7---------------\n§eGörev Adı:§f $sg\n§eAçıklama:§7 $dr\n§eKazanılan Ödül:§a +$para §fEM\n§7---------------");
$this->config->set("paragoz", "tamamlandi");
$this->config->set("max", "§aTamamlandı");
$this->config->set("secilengorev", "§fParaGöz,");
$this->config->set("random2", "§2TAMAMLANDI");
            $bt = $this->config->get("bitirdigingorevler");
                    $this->config->set("bitirdigingorevler", $bt+1);
$this->config->set("min", "§aGörev ");
		$this->config->save();

		}

		}
}

}
}
}
}
