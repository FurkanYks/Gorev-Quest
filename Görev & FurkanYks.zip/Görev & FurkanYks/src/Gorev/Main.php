<?php

namespace Gorev;
/*
"
		
    ______           __           __  ____       
   / ____/_  _______/ /______ ____\ \/ / /_______
  / /_  / / / / ___/ //_/ __ `/ __ \  / //_/ ___/
 / __/ / /_/ / /  / ,< / /_/ / / / / / ,< (__  ) 
/_/    \__,_/_/  /_/|_|\__,_/_/ /_/_/_/|_/____/  
                                                 
		"
		
		
		*@bu eklenti Genel Public Lisansı ile korunmaktadır, herhangi bir edit durumunda anında cezai işlemler uygulanır. eklentiyi ücretsiz bir şekilde https://github.com/FurkanYks/Gorev-Quest Adresinden indirebilirsiniz. eklentiyi yıldız atarak desteklerseniz güncellemer daha hızlı gelir.
		
		güncellemelerden haberdar olmak için https://github.com/FurkanYks/Gorev-Quest adresinden takipte kalın.
		
		
		bug ve hata bildirimleri için Messenger Veya YouTube kanalım üzerinden bana bildirebilirsiniz.
		
		@Messenger -> Furkan Yokuş
		
		@YouTube -> FurkanYks
		
		@Discord -> FurkanYks#5157
*/
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;
use pocketmine\event\Event;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\{Player, Server};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;


use Gorev\Events\BreakEvent;
use Gorev\Events\PlaceEvent;

use Gorev\Events\ChatEvent;
use Gorev\Events\DeathEvent;
use Gorev\Events\JoinEvent;

use Gorev\Events\FormEvent;

class Main extends PluginBase implements Listener{
    
    public $config;
    public $zaman;
    public $asd;
    
/*
.
          Author: FurkanYks
 */
    
    
public function onLoad(){
		
		
		
    $this->getLogger()->info("§aeklenti yükleniyor...");
	}
public function onEnable(){
		

		
    $this->getLogger()->info("§a
		
    ______           __           __  ____       
   / ____/_  _______/ /______ ____\ \/ / /_______
  / /_  / / / / ___/ //_/ __ `/ __ \  / //_/ ___/
 / __/ / /_/ / /  / ,< / /_/ / / / / / ,< (__  ) 
/_/    \__,_/_/  /_/|_|\__,_/_/ /_/_/_/|_/____/  
                                                 
		");
    
		@mkdir($this->getDataFolder());
@mkdir($this->getDataFolder()."Oyuncular/");


$this->zaman = new Config($this->getDataFolder() . "zaman.yml", Config::YAML);
  $this->asd = new Config($this->getDataFolder() . "gorevler.yml", Config::YAML,[
             "Zengin" => "§3Zengin",
             "BenBirMimarim" => "§3BenBirMimarım",
             "Elmass" => "§3Elmass",
             "Depo" => "§3Depo",
             "işsiz" => "§3işsiz",
             "ParaGöz" => "§3ParaGöz",
             "Oduncu" => "§3Oduncu",
             "Çaylak" => "§3Çaylak",
             "Savaşçı" => "§3Savaşçı"
        ]);



		$yonetici = $this->getServer()->getPluginManager();
		$yonetici->registerEvents($this, $this);


        $yonetici->registerEvents(new JoinEvent($this), $this);
        $yonetici->registerEvents(new BreakEvent($this), $this);
        
        $yonetici->registerEvents(new PlaceEvent($this), $this);
        $yonetici->registerEvents(new DeathEvent($this), $this);
        $yonetici->registerEvents(new ChatEvent($this), $this);
        $yonetici->registerEvents(new FormEvent($this), $this);
        

		
	}


	public function onCommand(CommandSender $o, Command $kmt, string $label, array $args): bool{
		switch($kmt->getName()){
			case "gorev":
 					$player = $o->getPlayer();
$this->gorevmenu($player);
		 	}

		return true;
	}
public function onDisable(){
		
		
		
    $this->getLogger()->info("§4
		
    ______           __           __  ____       
   / ____/_  _______/ /______ ____\ \/ / /_______
  / /_  / / / / ___/ //_/ __ `/ __ \  / //_/ ___/
 / __/ / /_/ / /  / ,< / /_/ / / / / / ,< (__  ) 
/_/    \__,_/_/  /_/|_|\__,_/_/ /_/_/_/|_/____/  
                                                 
		");
	}

	public function duzeltme(Player $o){
 					$player = $o->getPlayer();
if($this->config->get("random1") == "Çalışkan"){
$this->config->set("random11", $this->asd->get("Çalışkan"));
}
}
public function onaqJoin(PlayerJoinEvent $e){
		@mkdir($this->getDataFolder());
@mkdir($this->getDataFolder()."Oyuncular/");
		$o = $e->getPlayer();
		if(!file_exists($this->getDataFolder()."Oyuncular/".$o->getName().".yml")){
		$this->config = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

		$this->config->save();
		}
	}
	public function gorevmenu(Player $o){

 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$f = $api->createSimpleForm(function (Player $o, array $data){
				if(isset($data[0])){

				$result = $data[0];					
					if($result === null){						
					}
					switch($data[0]){
 				case 0:



 					$player = $o->getPlayer();
$this->gorevdurumu($player);


				







		break;
		case 1:

		        

 					$player = $o->getPlayer();
$this->gorevsec($player);

		    break;
		    case 2:

		        

 					$player = $o->getPlayer();

$this->bitengorevler($player);
		        break;
		        case 3:
 					$player = $o->getPlayer();
$this->tumgorevler($player);
		            break;


}
 			}
 	});
 	
 					$player = $o->getPlayer();
 					

                    




 	$f->setTitle("§8Görev Menüsü");

 	$f->addButton("§2Görev Durumu");
 	$f->addButton("Görev Seç");
 	$f->addButton("Biten Görevler");
 	$f->addButton("Tüm Görevler");

 	$f->sendToPlayer($o);

	}
	public function tumgorevler(Player $o){

 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$f = $api->createSimpleForm(function (Player $o, array $data){
				if(isset($data[0])){

				$result = $data[0];					
					if($result === null){						
					}
					switch($data[0]){
 				case 0:



 					$player = $o->getPlayer();
 					
$this->gorevmenu($player);


				







		break;



}
 			}
 	});
 	
 					$player = $o->getPlayer();
 					

                    




 	$f->setTitle("§8Tüm Görevler");
    $f->setContent("  §7-§e Tüm Görevlerin Listesi§7 -\n\n§e1- §7BenBirMimarım\n\n§e2-§7 Depo\n\n§e3-§7 Savaşçı\n\n§e4-§7 Çalışkan\n\n§e5- §7Elmass\n\n§e6-§7 işsiz\n\n§e7-§7 Çaylak\n\n§e8- §7ParaGöz\n\n§e9- §7Oduncu§7");
 	$f->addButton("§8Geri Dön");


 	$f->sendToPlayer($o);

	}
	public function bitengorevler(Player $o){

 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$f = $api->createSimpleForm(function (Player $o, array $data){
				if(isset($data[0])){

				$result = $data[0];					
					if($result === null){						
					}
					switch($data[0]){
 				case 0:



 					$player = $o->getPlayer();
 					
$this->gorevmenu($player);


				







		break;



}
 			}
 	});
 	
 					$player = $o->getPlayer();
 					

                    
              $bt = $this->config->get("bitirdigingorevler");



 	$f->setTitle("§8Biten Tüm Görevler");
    $f->setContent("  §7-§e Toplamda §f$bt §eGörev Tamamladın§7 -");
 	$f->addButton("§8Geri Dön");


 	$f->sendToPlayer($o);

	}
	public function gorevdurumu(Player $o){

 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$f = $api->createSimpleForm(function (Player $o, array $data){
				if(isset($data[0])){

				$result = $data[0];					
					if($result === null){						
					}
					switch($data[0]){
 				case 0:



 					$player = $o->getPlayer();
 					
$this->gorevmenu($player);


				







		break;



}
 			}
 	});
 	
 					$player = $o->getPlayer();
 					$o = $o->getPlayer();
 					
		$this->config = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

              $sg = $this->config->get("secilengorev");
              $dr = $this->config->get("aciklama");
              $max = $this->config->get("max");
              $min = $this->config->get("min");




 	$f->setTitle("§2Görev Durumun:");
    $f->setContent("§eGörev ismi:§b $sg \n\n\n§eAçıklama: §7$dr\n\n\n§dilerleme durumu:§f $min$max");
 	$f->addButton("§8Geri Dön");


 	$f->sendToPlayer($o);

	}
	public function gorevsec(Player $o){

 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$f = $api->createSimpleForm(function (Player $o, array $data){
				if(isset($data[0])){

				$result = $data[0];					
					if($result === null){						
					}
					switch($data[0]){
 				case 0:
 					$o = $o->getPlayer();
		$this->config = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

 					$player = $o->getPlayer();
if($this->config->get("random1") == "Çalışkan"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Çalışkan");
$this->config->set("aciklama", "10 adet çalışma masası koy!");
$this->config->set("max", "/10");
$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random1") == "Elmass"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Elmass");
$this->config->set("aciklama", "40 adet elmas bloğu kır!");
$this->config->set("max", "/40");
$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random1") == "BenBirMimarim"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "BenBirMimarim");

$this->config->set("aciklama", "250 adet herhangi bir blok koy!");
$this->config->set("max", "/250");
$this->config->set("min", "0");
		$this->config->save();
    
}


				







		break;
		case 1:
 					$o = $o->getPlayer();
		$this->config = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

 					$player = $o->getPlayer();
if($this->config->get("random2") == "Depo"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Depo");
$this->config->set("aciklama", "5 adet sandık koy!");
$this->config->set("max", "/5");
$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random2") == "işsiz"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "işsiz");
$this->config->set("aciklama", "650 kırıktaş kır!");
$this->config->set("max", "/650");
$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random2") == "ParaGöz"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "ParaGöz");
$this->config->set("aciklama", "80 adet elmas bloğu kır!");
$this->config->set("max", "/80");
$this->config->set("min", "0");
		$this->config->save();
    
}

		    break;
		    case 2:
 					$o = $o->getPlayer();
		$this->config = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

 					$player = $o->getPlayer();

if($this->config->get("random3") == "Oduncu"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Oduncu");
$this->config->set("aciklama", "64 adet odun kır!");
$this->config->set("max", "/64");
$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random3") == "Çaylak"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Çaylak");
$this->config->set("aciklama", "5 defa boşluğa düşerek öl!");
$this->config->set("max", "/5");

$this->config->set("min", "0");
		$this->config->save();
}
if($this->config->get("random3") == "Savaşçı"){
$player->sendMessage("§agörev başarıyla seçildi görev durumundan görev durumunuzu kontrol edebilirsiniz.");
                    $this->config->set("Zengin", 0);
		$this->config->save();
$this->config->set("secilengorev", "Savaşçı");
$this->config->set("aciklama", "10 kişiyi öldür!");
$this->config->set("max", "/10");
$this->config->set("min", "0");
		$this->config->save();
    
}
		        break;



}
 			}
 	});
 	
 					$player = $o->getPlayer();
 					$o = $o->getPlayer();
 					
		$this->configg = new Config($this->getDataFolder()."Oyuncular/".$o->getName().".yml", Config::YAML);

                    




 	$f->setTitle("§8Görev Seç");
    $f->setContent("sana uygun bir görev seç.");
		$f->addButton("".$this->configg->get("random1"));
		$f->addButton("".$this->configg->get("random2"));
		$f->addButton("".$this->configg->get("random3"));


 	$f->sendToPlayer($o);

	}
	
}
    
    