<?php

namespace Basarimlar;


use pocketmine\plugin\PluginBase;

use pocketmine\event\entity\EntityDamageByEntityEvent;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Event;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;

use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\{Player, Server};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;

class FurkanYks extends PluginBase implements Listener{
	
	public $cfg;
	public $config;
	public $level;
	public $toplambasarimlar;
	public $gerekentp;
	public $tbasarimlar;
	public $basarimdurumu;
	public $basarimdurum;
	public $tecrube;
	public $exp;
	public $saxp;
	public $basarimdurumbir;
	public $basarimdurumiki;
	public $xp;
	public $gxp;
	
	public function onEnable(){
		@mkdir($this->getDataFolder());		
		$this->saxp = new Config($this->getDataFolder() . "SeviyeAtlamaXp.yml", Config::YAML);
	$this->exp = new Config($this->getDataFolder() . "TecrubePuani.yml", Config::YAML);
	$this->basarimdurum = new Config($this->getDataFolder() . "BasarimDurum.yml", Config::YAML);
	$this->xp = new Config($this->getDataFolder() . "xp.yml", Config::YAML);
	$this->gxp = new Config($this->getDataFolder() . "gerekxp.yml", Config::YAML);
	$this->gerekentp = new Config($this->getDataFolder() . "gerekentp.yml", Config::YAML);
	$this->basarimdurumu = new Config($this->getDataFolder() . "basarimdurumuu.yml", Config::YAML);
	$this->basarimdurumbir = new Config($this->getDataFolder() . "basarimdurumburuu.yml", Config::YAML);
	$this->basarimdurumiki = new Config($this->getDataFolder() . "basarimdurumikiu.yml", Config::YAML);
$this->level = new Config($this->getDataFolder() . "Seviyeler.yml", Config::YAML);
$this->tecrube = new Config($this->getDataFolder() . "TecrubePuanlari.yml", Config::YAML);
$this->toplamparalar = new Config($this->getDataFolder() . "ToplamParalar.yml", Config::YAML);
$this->tbasarimlar = new Config($this->getDataFolder() . "TamamlananBasarimlar.yml", Config::YAML);
  $this->cfg = new Config($this->getDataFolder() . "Basarimlar.yml", Config::YAML,[
             "Seviyen" => "§cSeviyen: §7",
             "MevcutXp" => "§cMevcut XP: §7",
             "basarimtamamlandi" => "§aBaşarım Tamamlandı!",
             "tamamlanmadi" => "§cTamamlanmadı",
             "tamamlandiiki" => "§2Tamamlandı",
             "seviyeatlandii" => "§c",
             "seviyeatlandiii" => "§7",
             "tamamlandi" => "§aTamamlandı",
             "kazanilantp" => "§eKazanılan TP§7: §f"
        ]);
   $this->PureChat = $this->getServer()->getPluginManager()->getPlugin("PureChat");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getLogger()->info("
		
    ______           __           __  ____       
   / ____/_  _______/ /______ ____\ \/ / /_______
  / /_  / / / / ___/ //_/ __ `/ __ \  / //_/ ___/
 / __/ / /_/ / /  / ,< / /_/ / / / / / ,< (__  ) 
/_/    \__,_/_/  /_/|_|\__,_/_/ /_/_/_/|_/____/  
                                                 
		");
	}
	
	public function onCommand(CommandSender $sender, Command $kmt, string $label, array $args): bool{
		$user = $sender->getPlayer()->getName();
		$user2 = $sender->getPlayer();
		if($kmt->getName() == "gorev"){
			$this->anamenu($sender);
		}
		

 }
    
	public function blockKırmaEvent(BlockBreakEvent $e){
		$user = $e->getPlayer()->getName();
		$user2 = $e->getPlayer();	
	$block = $e->getBlock();
	$oyuncu = $e->getPlayer();
	$isim = $e->getPlayer()->getName();


		    
 


		}

		    
  

		if($this->exp->get($user) <= 299){
     } else {
		if($this->exp->get($user) < $this->saxp->get($user)){
$this->exp->set($user, $this->exp->get($user) -1);
     }
}
		if($this->exp->get($user) < $this->saxp->get($user)){
$this->exp->set($user, $this->exp->get($user) +1);
     } else {
         
               $this->exp->set($user, 300);
               $this->tbasarimlar->set($user,$this->tbasarimlar->get($user) +1);
               $this->saxp->set($user,$this->saxp->get($user) +9999999);
            $this->basarimdurumu->set($user, $this->cfg->get("tamamlandi"));
            $this->basarimdurum->set($user, $this->cfg->get("tamamlandiiki"));

 $this->benmimarim($user2);
         $this->saxp->save();
        $this->level->save();
        $this->basarimdurumu->save();
        $this->basarimdurum->save();
        $this->tecrube->save();
        $this->tbasarimlar->save();
        $this->toplambasarimlar->save();
       $this->exp->save();
           }
    }
public function benmimarim($player){
    $form = new ModalForm(function (Player $event, $data){
      $player = $event->getPlayer();
      $oyuncu = $player->getName();
      
      if($data === null){
        return;
      }
      switch($data){
        case 0:
            //alt buton
$this->basarimlar($player);
        break;
        case 1:
            //üst Buton
//kit Seçme Ekle

	   	

            break;

      	 

      }
    });
    $form->setTitle("§2Görev Tamamlandı!");

$form->setButton1("Tamam");
$form->setButton2("Görevlere Göz At ");
    $form->setContent("§eTamamlanan Görev: §fBen Bir Mimarım\n§eGörev Açıklaması: §f300 adet blok koy.\n§eKazandığın ödül: §f3 adet §bElmas§f kasa anahtarı");
    
    $form->sendToPlayer($player);
  }
  public function oyunagiris(PlayerJoinEvent $event){
      	$user = $event->getPlayer()->getName();
      	if($this->saxp->get($user) > 0){
        } else {
            $this->saxp->set($user, 300);

            $this->tbasarimlar->set($user, 0);
            $this->tecrube->set($user, 0);
            $this->gerekentp->set($user, 0);
            $this->basarimdurumu->set($user, $this->cfg->get("tamamlanmadi"));
            $this->basarimdurum->set($user, $this->cfg->get("tamamlanmadi"));
            $this->toplamparalar->set($user, 0);
            $this->exp->set($user, 0);
            	}

      	if($this->gxp->get($user) > 0){
        } else {
            $this->gxp->set($user, 500);
            $this->basarimdurumbir->set($user, $this->cfg->get("tamamlanmadi"));
            $this->basarimdurumiki->set($user, $this->cfg->get("tamamlanmadi"));
            $this->xp->set($user, 0);
        }
  }
	public function seviyeForm(Player $sender){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $sender, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			switch($re){
				case 0:
				    $this->anamenu($sender);
				break;
				case 1:
				    break;
				    
			}
		});
		$f->setTitle("§8Görev Menüsü");
		$f->setContent("\n\n\n§eTamamlanan Görevler§7:§f ".$this->tbasarimlar->get($sender->getName())."\n§eKazanılan Toplam Paralar:§f ".$this->toplamparalar->get($sender->getName())."§fEM");
		$f->addButton("Geri Dön");
		$f->addButton("Menüyü Kapat");
		$f->sendToPlayer($sender);
	}
	public function anamenu(Player $sender){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $sender, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			switch($re){
				case 0:
				    $this->anamenu($sender);
				break;
				case 1:
				    break;
				    case 2:
				        break;
				        case 3:
				            break;
				            case 4:
				                break;
				    
			}
		});
		$f->setTitle("§8Görev Menüsü");

		$f->addButton("§2Görev Durumu");
		$f->addButton("Görev Seç");
		$f->addButton("Biten Görevler");
		$f->addButton("Tüm Görevler");
		$f->addButton("Menüyü Kapat");
		$f->sendToPlayer($sender);
	}

	public function basarim1(Player $sender){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $sender, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			switch($re){
				case 0:
				    $this->basarimlar($sender);
				    break;
				    
			}
		});
		$f->setTitle("Başarım Menüsü");
		$f->setContent("\n\n\n§aBaşarım Adı§7:§f Madenci\n\n\n\n§aBaşarım Açıklaması§7:§f 64 Blok Kır\n\n\n§aBaşarım Kazancı§7:§e \n§e+100 Tecrübe Puanı\n§6+30 Coin\n\n\n§eMevcut Tecrübe Puanı§7:§f ".$this->tecrube->get($sender->getName())."\n\n\n§eBaşarım ilerlemesi§7:§f ".$this->exp->get($sender->getName())."§7/§f64\n\n\n§eBaşarım Durumu§7:§f ".$this->basarimdurumu->get($sender->getName()));
		$f->addButton("Geri Dön");
		$f->sendToPlayer($sender);
	}
	public function basarim2(Player $sender){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $sender, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			switch($re){
				case 0:
				    $this->basarimlar($sender);
				    break;
				    
			}
		});
		$f->setTitle("Başarım Menüsü");
		$f->setContent("\n\n\n§aBaşarım Adı§7:§f Ben Bir Mimarım\n\n\n\n§aBaşarım Açıklaması§7:§f 500 Blok Koy\n\n\n§aBaşarım Kazancı§7:§e \n§e+100 Tecrübe Puanı\n§6+50 Coin\n\n\n§eMevcut Tecrübe Puanı§7:§f ".$this->tecrube->get($sender->getName())."\n\n\n§eBaşarım ilerlemesi§7:§f ".$this->xp->get($sender->getName())."§7/§f500\n\n\n§eBaşarım Durumu§7:§f ".$this->basarimdurumbir->get($sender->getName()));
		$f->addButton("Geri Dön");
		$f->sendToPlayer($sender);
	}
	public function basarimlar(Player $sender){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $sender, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			switch($re){
				case 0:
				    $this->basarim1($sender);
				    break;
				    case 1:
				        $this->basarim2($sender);
				    break;
				    case 2:
				        $this->seviyeForm($sender);
				        break;
				    
			}
		});
		$f->setTitle("Başarım Menüsü");
		$f->setContent("§a");
		$f->addButton("Madenci\n".$this->basarimdurum->get($sender->getName()));
		$f->addButton("Ben Bir Mimarım\n".$this->basarimdurumiki->get($sender->getName()));
		$f->addButton("Geri Dön");
		$f->sendToPlayer($sender);
	}
	public function blockKoymaEvent(BlockPlaceEvent $e){
		$user = $e->getPlayer()->getName();
		$user2 = $e->getPlayer();	
	$block = $e->getBlock();
	$oyuncu = $e->getPlayer();
	$isim = $e->getPlayer()->getName();
		if($this->tecrube->get($user) == 200){
 $user2->sendPopup($this->cfg->get("seviyeatlandiii"));
 $user2->sendPopup($this->cfg->get("seviyeatlandii"));
 
               $this->level->set($user,$this->level->get($user) +1);
               $this->PureChat->setPrefix($this->level->get($user), $e->getPlayer());
		}
		if($this->level->get($user) == 3){
		    
 
               $this->level->set($user,$this->level->get($user) +1);
               $this->PureChat->setPrefix($this->level->get($user), $e->getPlayer());
		}
		if($this->level->get($user) >= 4){
		    
 
               $this->level->set($user,$this->level->get($user) -1);
               $this->PureChat->setPrefix($this->level->get($user), $e->getPlayer());
		}
		if($this->xp->get($user) <= 499){
     } else {
		if($this->xp->get($user) < $this->gxp->get($user)){
$this->xp->set($user, $this->xp->get($user) -1);
     }
}
		if($this->xp->get($user) < $this->gxp->get($user)){
$this->xp->set($user, $this->xp->get($user) +1);
     } else {
         
               $this->xp->set($user, 500);
               $this->tbasarimlar->set($user,$this->tbasarimlar->get($user) +1);
               $this->gxp->set($user,$this->gxp->get($user) +9999999);
            $this->basarimdurumbir->set($user, $this->cfg->get("tamamlandi"));
            $this->basarimdurumiki->set($user, $this->cfg->get("tamamlandiiki"));
               $this->tecrube->set($user,$this->tecrube->get($user) +100);
 $user2->sendMessage($this->cfg->get("basarimtamamlandi"), $this->cfg->get("kazanilantp") . $this->xp->get($user));
 $user2->sendMessage("§7----------------");
 $user2->sendMessage("§aTamamlanan Başarım§b:§f Ben Bir Mimarım");
 $user2->sendMessage("§aBaşarım Açıklaması§b:§f 500 Blok Koy");
 $user2->sendMessage("§e+100 Tecrübe Puanı");
 $user2->sendMessage("§6+50 Coin");
 $user2->sendMessage("§7----------------");
         $this->gxp->save();
        $this->level->save();
        $this->basarimdurumbir->save();
        $this->basarimdurumiki->save();
        $this->basarimdurumu->save();
        $this->basarimdurum->save();
        $this->tecrube->save();
        $this->tbasarimlar->save();
        $this->toplambasarimlar->save();
       $this->xp->save();
           }
    }
}
